<?php
// public/index.php - アプリケーションのエントリーポイント

// インストールチェック: database.php が存在しない場合はインストーラーへリダイレクト
if (!file_exists(__DIR__ . '/../config/database.php') && file_exists(__DIR__ . '/install.php') && !file_exists(__DIR__ . '/../install.lock')) {
    header('Location: install.php');
    exit;
}

// 基本設定
session_start();
date_default_timezone_set('Asia/Tokyo');

// エラー表示設定（本番ホストは常に非表示）
$host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
$isProductionHost = in_array($host, [
    'groupware.yuus-program.com',
    'www.groupware.yuus-program.com'
], true);
$appDebug = false;
if (file_exists(__DIR__ . '/../config/config.php')) {
    $tmpConfig = require __DIR__ . '/../config/config.php';
    $appDebug = !empty($tmpConfig['app']['debug']);
}
$displayErrors = $appDebug && !$isProductionHost;
ini_set('display_errors', $displayErrors ? '1' : '0');
error_reporting($displayErrors ? E_ALL : (E_ALL & ~E_DEPRECATED & ~E_STRICT));
mb_internal_encoding('UTF-8');

// アプリケーションのベースパスを設定
$basePath = dirname($_SERVER["SCRIPT_NAME"]);
if ($basePath == "/") $basePath = "";
// /public を除去（ルートの.htaccessからリダイレクトされた場合）
$basePath = preg_replace('#/public$#', '', $basePath);
define("BASE_PATH", $basePath);

// オートローダー設定
spl_autoload_register(function ($class) {
    // 名前空間を考慮してファイルパスに変換
    $path = str_replace('\\', DIRECTORY_SEPARATOR, $class);
    $file = __DIR__ . '/../' . $path . '.php';

    // 標準パスでファイルを探す
    if (file_exists($file)) {
        require_once $file;
        return true;
    }

    // 小文字のパスで試す
    $lowercasePath = strtolower($path);
    $file = __DIR__ . '/../' . $lowercasePath . '.php';

    if (file_exists($file)) {
        require_once $file;
        return true;
    }

    // 大文字と小文字を入れ替えたパスで試す (Core -> core)
    $altPath = str_ireplace('Core', 'core', $path);
    $file = __DIR__ . '/../' . $altPath . '.php';

    if (file_exists($file)) {
        require_once $file;
        return true;
    }

    return false;
});

require_once __DIR__ . '/../Core/i18n_functions.php';
\Core\I18n::init($_GET['lang'] ?? null);

// コアクラスのインスタンス取得
$router = Core\Router::getInstance();
$auth = Core\Auth::getInstance();
$config = require_once __DIR__ . '/../config/config.php';

// Remember Me トークンからの認証
if (!$auth->check()) {
    $auth->authenticateFromRememberToken();
}

// PWA公開エンドポイント（認証不要）
$router->get('/manifest.json', function () {
    $controller = new Controllers\PwaController();
    $controller->manifest();
});

$router->get('/service-worker.js', function () {
    $controller = new Controllers\PwaController();
    $controller->serviceWorker();
});

$router->get('/offline', function () {
    $controller = new Controllers\PwaController();
    $controller->offline();
});

$router->get('/icons/:name', function ($params) {
    $name = (string)($params['name'] ?? '');
    if ($name === '' || !preg_match('/^[a-zA-Z0-9._-]+$/', $name)) {
        http_response_code(400);
        echo 'Invalid icon name';
        exit;
    }

    $iconPath = __DIR__ . '/icons/' . $name;
    if (!is_file($iconPath)) {
        http_response_code(404);
        echo 'Icon not found';
        exit;
    }

    $extension = strtolower((string)pathinfo($iconPath, PATHINFO_EXTENSION));
    $contentTypes = [
        'png' => 'image/png',
        'svg' => 'image/svg+xml',
        'ico' => 'image/x-icon',
        'webp' => 'image/webp'
    ];
    header('Content-Type: ' . ($contentTypes[$extension] ?? 'application/octet-stream'));
    header('Cache-Control: public, max-age=86400');
    readfile($iconPath);
    exit;
});

$router->get('/locale/:lang', function ($params) {
    $requested = (string)($params['lang'] ?? '');
    $locale = set_locale($requested, true);

    $redirect = (string)($_GET['redirect'] ?? ($_SERVER['HTTP_REFERER'] ?? '/'));
    $parsed = parse_url($redirect);

    // 外部URLオープンリダイレクトを防止し、同一アプリ内パスに限定
    if (!empty($parsed['host']) && strcasecmp((string)$parsed['host'], (string)($_SERVER['HTTP_HOST'] ?? '')) !== 0) {
        $redirect = '/';
    } else {
        $path = (string)($parsed['path'] ?? $redirect);
        $query = isset($parsed['query']) ? ('?' . $parsed['query']) : '';
        $redirect = ($path !== '' ? $path : '/') . $query;
    }

    if ($redirect === '' || $redirect[0] !== '/') {
        $redirect = '/';
    }

    if (BASE_PATH !== '' && strpos($redirect, BASE_PATH) !== 0) {
        $redirect = BASE_PATH . $redirect;
    }

    // ループ防止
    if (strpos($redirect, '/locale/') !== false) {
        $redirect = BASE_PATH . '/';
    }

    header('X-App-Locale: ' . $locale);
    header('Location: ' . $redirect);
    exit;
});

$router->apiPost('/i18n/translate', function ($params, $data) {
    $text = trim((string)($data['text'] ?? ''));
    if ($text === '' || mb_strlen($text) > 280) {
        return ['error' => tr_text('翻訳対象テキストが不正です。', 'Invalid translation target text.'), 'code' => 422];
    }

    return [
        'success' => true,
        'message' => \Core\RuntimeI18n::translatePlainText($text),
    ];
}, false);

// ルーティングの設定
// ホームページ 
$router->get('/', function () use ($auth) {
    if ($auth->check()) {
        $controller = new Controllers\HomeController();
        $controller->index();
    } else {
        header('Location: ' . BASE_PATH . '/login');
    }
});

// 認証関連
$router->get('/login', function () use ($auth) {
    if ($auth->check()) {
        header('Location: ' . BASE_PATH . '/');
        exit;
    }

    \Core\RuntimeI18n::renderPhp(__DIR__ . '/../views/auth/login.php');
});

$router->post('/login', function () use ($auth) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']) ? true : false;

    $settingModel = new Models\Setting();
    $ssoEnabled = filter_var((string)$settingModel->get('sso_enabled', '0'), FILTER_VALIDATE_BOOLEAN);
    $localEnabled = filter_var((string)$settingModel->get('sso_local_login_enabled', '1'), FILTER_VALIDATE_BOOLEAN);
    if ($ssoEnabled && !$localEnabled) {
        $_SESSION['login_error'] = t('auth.error.local_login_disabled');
        header('Location: ' . BASE_PATH . '/login/local-admin');
        exit;
    }

    if ($auth->login($username, $password, $remember)) {
        $redirect = $_GET['redirect'] ?? '/';
        header('Location: ' . BASE_PATH . $redirect);
    } else {
        $_SESSION['login_error'] = $auth->getLastError() ?: t('auth.error.invalid_credentials');
        header('Location: ' . BASE_PATH . '/login');
    }
});

$router->get('/logout', function () use ($auth) {
    $auth->logout();
    header('Location: ' . BASE_PATH . '/login');
});

// SSO誤設定時の非常口: ローカル管理者専用ログイン
$router->get('/login/local-admin', function () {
    $controller = new Controllers\SsoController();
    $controller->localAdminLoginForm();
});

$router->post('/login/local-admin', function () {
    $controller = new Controllers\SsoController();
    $controller->localAdminLoginPost();
});

// SSO/OIDC/SAML
$router->get('/auth/oidc/login', function () {
    $controller = new Controllers\SsoController();
    $controller->oidcLogin();
});

$router->get('/auth/oidc/callback', function () {
    $controller = new Controllers\SsoController();
    $controller->oidcCallback();
});

$router->get('/auth/saml/login', function () {
    $controller = new Controllers\SsoController();
    $controller->samlLogin();
});

$router->post('/auth/saml/acs', function () {
    $controller = new Controllers\SsoController();
    $controller->samlAcs();
});

$router->get('/auth/saml/metadata', function () {
    $controller = new Controllers\SsoController();
    $controller->samlMetadata();
});

// 組織管理
$router->get('/organizations', function () {
    $controller = new Controllers\OrganizationController();
    $controller->index();
}, true);

$router->get('/organizations/create', function () {
    $controller = new Controllers\OrganizationController();
    $controller->create();
}, true);

$router->get('/organizations/edit/:id', function ($params) {
    $controller = new Controllers\OrganizationController();
    $controller->edit($params);
}, true);

$router->get('/organizations/view/:id', function ($params) {
    $controller = new Controllers\OrganizationController();
    $controller->viewDetails($params);
}, true);

// ユーザー管理
$router->get('/users', function () {
    $controller = new Controllers\UserController();
    $controller->index();
}, true);

$router->get('/users/create', function () {
    $controller = new Controllers\UserController();
    $controller->create();
}, true);

$router->get('/users/edit/:id', function ($params) {
    $controller = new Controllers\UserController();
    $controller->edit($params);
}, true);

$router->get('/users/view/:id', function ($params) {
    $controller = new Controllers\UserController();
    $controller->viewDetails($params);
}, true);

$router->get('/users/change-password/:id', function ($params) {
    $controller = new Controllers\UserController();
    $controller->changePassword($params);
}, true);

// スケジュール管理
$router->get('/schedule', function () {
    header('Location:' . BASE_PATH . '/schedule/month');
    exit;
}, true);

$router->get('/schedule/day', function () {
    $controller = new Controllers\ScheduleController();
    $controller->day();
}, true);

$router->get('/schedule/week', function () {
    $controller = new Controllers\ScheduleController();
    $controller->week();
}, true);

$router->get('/schedule/month', function () {
    $controller = new Controllers\ScheduleController();
    $controller->month();
}, true);

$router->get('/schedule/create', function () {
    $controller = new Controllers\ScheduleController();
    $controller->create();
}, true);

$router->get('/schedule/edit/:id', function ($params) {
    $controller = new Controllers\ScheduleController();
    $controller->edit($params);
}, true);

$router->get('/schedule/view/:id', function ($params) {
    $controller = new Controllers\ScheduleController();
    $controller->viewDetails($params);
}, true);

// 組織スケジュール管理
$router->get('/schedule/organization-day', function () {
    $controller = new Controllers\ScheduleController();
    $controller->organizationDay();
}, true);

$router->get('/schedule/organization-week', function () {
    $controller = new Controllers\ScheduleController();
    $controller->organizationWeek();
}, true);

$router->get('/schedule/organization-month', function () {
    $controller = new Controllers\ScheduleController();
    $controller->organizationMonth();
}, true);

// API ルート

// 組織管理API
$router->apiGet('/organizations', function () {
    $controller = new Controllers\OrganizationController();
    return $controller->apiGetAll();
}, true);

$router->apiGet('/organizations/tree', function () {
    $controller = new Controllers\OrganizationController();
    return $controller->apiGetTree();
}, true);

$router->apiGet('/organizations/:id', function ($params) {
    $controller = new Controllers\OrganizationController();
    return $controller->apiGetOne($params);
}, true);

$router->apiPost('/organizations', function ($params, $data) {
    $controller = new Controllers\OrganizationController();
    return $controller->apiCreate($params, $data);
}, true);

$router->apiPost('/organizations/:id', function ($params, $data) {
    $controller = new Controllers\OrganizationController();
    return $controller->apiUpdate($params, $data);
}, true);

$router->apiDelete('/organizations/:id', function ($params) {
    $controller = new Controllers\OrganizationController();
    return $controller->apiDelete($params);
}, true);

$router->apiPost('/organizations/:id/move', function ($params, $data) {
    $controller = new Controllers\OrganizationController();
    return $controller->apiUpdateOrder($params, $data);
}, true);

// 組織コード重複チェックAPI
$router->apiGet('/organizations/check-code', function ($params) {
    $controller = new Controllers\OrganizationController();
    return $controller->apiCheckCodeUnique($params);
}, true);

// 組織のユーザー一覧を取得
$router->apiGet('/organizations/:id/users', function ($params) {
    $controller = new Controllers\OrganizationController();
    return $controller->apiGetUsers($params);
}, true);

// ユーザー管理API
$router->apiGet('/users', function ($params) {
    $controller = new Controllers\UserController();
    return $controller->apiGetAll($params);
}, true);

$router->apiGet('/users/:id', function ($params) {
    $controller = new Controllers\UserController();
    return $controller->apiGetOne($params);
}, true);

$router->apiGet('/users/:id/organizations', function ($params) {
    $controller = new Controllers\UserController();
    return $controller->apiGetUserOrganizations($params);
}, true);

$router->apiPost('/users', function ($params, $data) {
    $controller = new Controllers\UserController();
    return $controller->apiCreate($params, $data);
}, true);

$router->apiPost('/users/:id', function ($params, $data) {
    $controller = new Controllers\UserController();
    return $controller->apiUpdate($params, $data);
}, true);

$router->apiDelete('/users/:id', function ($params) {
    $controller = new Controllers\UserController();
    return $controller->apiDelete($params);
}, true);

$router->apiPost('/users/:id/change-password', function ($params, $data) {
    $controller = new Controllers\UserController();
    return $controller->apiChangePassword($params, $data);
}, true);

$router->apiPost('/users/:id/primary-organization', function ($params, $data) {
    $controller = new Controllers\UserController();
    return $controller->apiChangePrimaryOrganization($params, $data);
}, true);

// スケジュール管理API
$router->apiGet('/schedule/day', function ($params) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiGetDay($params);
}, true);

$router->apiGet('/schedule/week', function ($params) {
    $controller = new Controllers\ScheduleController();
    error_log(json_encode(['debug:apigetweek:' => $params]));
    return $controller->apiGetWeek($params);
}, true);

$router->apiGet('/schedule/month', function ($params) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiGetMonth($params);
}, true);

$router->apiGet('/schedule/range', function ($params) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiGetByDateRange($params);
}, true);

$router->apiGet('/schedule/organization-week', function ($params) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiGetOrganizationWeek($params);
}, true);

$router->apiGet('/schedule/organization-day', function ($params) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiGetOrganizationDay($params);
}, true);

$router->apiGet('/schedule/organization-month', function ($params) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiGetOrganizationMonth($params);
}, true);

$router->apiGet('/schedule/:id', function ($params) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiGetOne($params);
}, true);

$router->apiPost('/schedule', function ($params, $data) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiCreate($params, $data);
}, true);

$router->apiPost('/schedule/:id', function ($params, $data) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiUpdate($params, $data);
}, true);

$router->apiDelete('/schedule/:id', function ($params) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiDelete($params);
}, true);

$router->apiPost('/schedule/:id/participation-status', function ($params, $data) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiUpdateParticipantStatus($params, $data);
}, true);

$router->apiPost('/schedule/:id/participants', function ($params, $data) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiAddParticipant($params, $data);
}, true);

$router->apiDelete('/schedule/:id/participants', function ($params, $data) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiRemoveParticipant($params, $data);
}, true);

$router->apiPost('/schedule/:id/organizations', function ($params, $data) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiAddOrganization($params, $data);
}, true);

$router->apiDelete('/schedule/:id/organizations', function ($params, $data) {
    $controller = new Controllers\ScheduleController();
    return $controller->apiRemoveOrganization($params, $data);
}, true);

// アクティブユーザー取得API
$router->apiGet('/active-users', function () {
    $controller = new Controllers\UserController();
    return $controller->apiGetActiveUsers();
}, true);

// ワークフロー関連のルーティング
// ワークフロー管理画面
$router->get('/workflow', function () {
    $controller = new Controllers\WorkflowController();
    $controller->index();
}, true);

// テンプレート一覧
$router->get('/workflow/templates', function () {
    $controller = new Controllers\WorkflowController();
    $controller->templates();
}, true);

// テンプレート作成画面
$router->get('/workflow/create-template', function () {
    $controller = new Controllers\WorkflowController();
    $controller->createTemplate();
}, true);

// テンプレート編集画面
$router->get('/workflow/edit-template/:id', function ($params) {
    $controller = new Controllers\WorkflowController();
    $controller->editTemplate($params);
}, true);

// フォームデザイナー画面
$router->get('/workflow/design-form/:id', function ($params) {
    $controller = new Controllers\WorkflowController();
    $controller->designForm($params);
}, true);

// 承認経路設定画面
$router->get('/workflow/design-route/:id', function ($params) {
    $controller = new Controllers\WorkflowController();
    $controller->designRoute($params);
}, true);

// 申請一覧画面
$router->get('/workflow/requests', function () {
    $controller = new Controllers\WorkflowController();
    $controller->requests();
}, true);

// 新規申請テンプレート選択画面
$router->get('/workflow/create', function () {
    $controller = new Controllers\WorkflowController();
    $controller->selectTemplate();
}, true);

// 承認待ち一覧画面
$router->get('/workflow/approvals', function () {
    $controller = new Controllers\WorkflowController();
    $controller->approvals();
}, true);

// 新規申請作成画面
$router->get('/workflow/create/:id', function ($params) {
    $controller = new Controllers\WorkflowController();
    $controller->create($params);
}, true);

// 申請編集画面
$router->get('/workflow/edit/:id', function ($params) {
    $controller = new Controllers\WorkflowController();
    $controller->edit($params);
}, true);

// 申請詳細画面
$router->get('/workflow/view/:id', function ($params) {
    $controller = new Controllers\WorkflowController();
    $controller->viewDetails($params);
}, true);

// 代理承認設定画面
$router->get('/workflow/delegates', function () {
    $controller = new Controllers\WorkflowController();
    $controller->delegates();
}, true);

// API ルート
// テンプレート関連API
$router->apiGet('/workflow/templates', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiGetAllTemplates($params);
}, true);

$router->apiGet('/workflow/templates/:id', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiGetTemplate($params);
}, true);

$router->apiPost('/workflow/templates', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiCreateTemplate($params, $data);
}, true);

$router->apiPost('/workflow/templates/:id', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiUpdateTemplate($params, $data);
}, true);

$router->apiDelete('/workflow/templates/:id', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiDeleteTemplate($params);
}, true);

// フォーム関連API
$router->apiGet('/workflow/templates/:id/form', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiGetTemplate($params);
}, true);

$router->apiPost('/workflow/templates/:id/form', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiSaveFormDefinitions($params, $data);
}, true);

$router->apiPost('/workflow/templates/:id/form-fields', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiAddFormField($params, $data);
}, true);

$router->apiPost('/workflow/templates/:id/form-fields/:field_id', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiUpdateFormField($params, $data);
}, true);

$router->apiDelete('/workflow/templates/:id/form-fields/:field_id', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiDeleteFormField($params);
}, true);

// 承認経路関連API
$router->apiGet('/workflow/templates/:id/route', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiGetTemplate($params);
}, true);

$router->apiPost('/workflow/templates/:id/route', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiSaveRouteDefinitions($params, $data);
}, true);

$router->apiPost('/workflow/templates/:id/route-steps', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiAddRouteStep($params, $data);
}, true);

$router->apiPost('/workflow/templates/:id/route-steps/:step_id', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiUpdateRouteStep($params, $data);
}, true);

$router->apiDelete('/workflow/templates/:id/route-steps/:step_id', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiDeleteRouteStep($params);
}, true);

// 申請関連API
$router->apiGet('/workflow/requests', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiGetRequests($params);
}, true);

$router->apiGet('/workflow/requests/:id', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiGetRequest($params);
}, true);

$router->apiPost('/workflow/requests', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiCreateRequest($params, $data);
}, true);

$router->apiPost('/workflow/requests/:id', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiUpdateRequest($params, $data);
}, true);

$router->apiDelete('/workflow/requests/:id', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiCancelRequest($params);
}, true);

// 承認関連API
$router->apiPost('/workflow/requests/:id/approve', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiProcessApproval($params, $data);
}, true);

$router->apiPost('/workflow/requests/:id/comments', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiAddComment($params, $data);
}, true);

// 代理承認設定API
$router->apiPost('/workflow/delegates', function ($params, $data) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiAddDelegation($params, $data);
}, true);

// エクスポートAPI
$router->apiGet('/workflow/requests/:id/export/pdf', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiExportPdf($params);
}, true);

$router->apiGet('/workflow/requests/:id/export/csv', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiExportCsv($params);
}, true);

// 統計情報API
$router->apiGet('/workflow/stats', function ($params) {
    $controller = new Controllers\WorkflowController();
    return $controller->apiGetStats($params);
}, true);

// メッセージ機能のルーティング
// /messages -> /messages/inbox へリダイレクト
$router->get('/messages', function () {
    header('Location: ' . BASE_PATH . '/messages/inbox');
    exit;
}, true);

// メッセージの受信トレイ
$router->get('/messages/inbox', function () {
    $controller = new Controllers\MessageController();
    $controller->inbox();
}, true);

// 送信済みメッセージ
$router->get('/messages/sent', function () {
    $controller = new Controllers\MessageController();
    $controller->sent();
}, true);

// スター付きメッセージ
$router->get('/messages/starred', function () {
    $controller = new Controllers\MessageController();
    $controller->starred();
}, true);

// 新規メッセージ作成
$router->get('/messages/compose', function () {
    $controller = new Controllers\MessageController();
    $controller->create();
}, true);

// メッセージ返信
$router->get('/messages/reply/:id', function ($params) {
    $controller = new Controllers\MessageController();
    $controller->reply($params);
}, true);

// 全員に返信
$router->get('/messages/reply-all/:id', function ($params) {
    $controller = new Controllers\MessageController();
    $controller->replyAll($params);
}, true);

// メッセージ転送
$router->get('/messages/forward/:id', function ($params) {
    $controller = new Controllers\MessageController();
    $controller->forward($params);
}, true);

// メッセージ詳細表示
$router->get('/messages/view/:id', function ($params) {
    $controller = new Controllers\MessageController();
    $controller->viewDetails($params);
}, true);

// メッセージAPI
// メッセージ送信API
$router->apiPost('/messages/send', function ($params, $data) {
    $controller = new Controllers\MessageController();
    return $controller->apiSend($params, $data);
}, true);

// 既読にするAPI
$router->apiPost('/messages/:id/read', function ($params, $data) {
    $controller = new Controllers\MessageController();
    return $controller->apiMarkAsRead($params, $data);
}, true);

// 未読にするAPI
$router->apiPost('/messages/:id/unread', function ($params, $data) {
    $controller = new Controllers\MessageController();
    return $controller->apiMarkAsUnread($params, $data);
}, true);

// スター付けAPI
$router->apiPost('/messages/:id/star', function ($params, $data) {
    $controller = new Controllers\MessageController();
    return $controller->apiToggleStar($params, $data);
}, true);

// メッセージ削除API
$router->apiDelete('/messages/:id', function ($params) {
    $controller = new Controllers\MessageController();
    return $controller->apiDelete($params);
}, true);

// 未読メッセージ数API
$router->apiGet('/messages/unread-count', function () {
    $controller = new Controllers\MessageController();
    return $controller->apiGetUnreadCount();
}, true);

// チャット機能
$router->get('/chat', function () {
    $controller = new Controllers\ChatController();
    $controller->index();
}, true);

$router->get('/chat/room/:id', function ($params) {
    $roomId = (int)($params['id'] ?? 0);
    header('Location: ' . BASE_PATH . '/chat?room_id=' . $roomId);
    exit;
}, true);

$router->post('/chat/rooms/create', function () {
    $controller = new Controllers\ChatController();
    $controller->createRoom();
}, true);

$router->post('/chat/rooms/:id/update', function ($params) {
    $controller = new Controllers\ChatController();
    $controller->updateRoom($params);
}, true);

$router->post('/chat/rooms/:id/message', function ($params) {
    $controller = new Controllers\ChatController();
    $controller->postMessage($params);
}, true);

$router->get('/chat/files/:id/download', function ($params) {
    $controller = new Controllers\ChatController();
    $controller->downloadAttachment($params);
}, true);

$router->apiGet('/chat/rooms', function () {
    $controller = new Controllers\ChatController();
    return $controller->apiRooms();
}, true);

$router->apiGet('/chat/rooms/:id/messages', function ($params) {
    $controller = new Controllers\ChatController();
    return $controller->apiMessages($params);
}, true);

$router->apiGet('/chat/rooms/:room_id/messages/:message_id/readers', function ($params) {
    $controller = new Controllers\ChatController();
    return $controller->apiMessageReaders($params);
}, true);

$router->apiPost('/chat/rooms/:id/read', function ($params, $data) {
    $controller = new Controllers\ChatController();
    return $controller->apiRead($params, $data);
}, true);

$router->apiGet('/chat/unread-count', function () {
    $controller = new Controllers\ChatController();
    return $controller->apiUnreadCount();
}, true);

// システム設定関連のルート
// 基本設定
$router->get('/settings', function () {
    $controller = new Controllers\SettingController();
    $controller->index();
}, true);

// SMTP設定
$router->get('/settings/smtp', function () {
    $controller = new Controllers\SettingController();
    $controller->smtp();
}, true);

// 通知設定
$router->get('/settings/notification', function () {
    $controller = new Controllers\SettingController();
    $controller->notification();
}, true);

// 認証/PWA/SCIM設定
$router->get('/settings/security', function () {
    $controller = new Controllers\SettingController();
    $controller->security();
}, true);

$router->get('/settings/backup/download/:id', function ($params) {
    $controller = new Controllers\SettingController();
    $controller->downloadBackup($params);
}, true);

// システム設定API
$router->apiPost('/settings', function ($params, $data) {
    $controller = new Controllers\SettingController();
    return $controller->apiUpdate($params, $data);
}, true);

// SMTPテストAPI
$router->apiPost('/settings/test-smtp', function ($params, $data) {
    $controller = new Controllers\SettingController();
    return $controller->apiTestSmtp($params, $data);
}, true);

// メール送信処理API
$router->apiPost('/settings/process-email-queue', function ($params, $data) {
    $controller = new Controllers\NotificationController();
    $notificationModel = new Models\Notification();
    $result = $notificationModel->processEmailQueue(20);

    return [
        'success' => $result['success'],
        'message' => $result['message'],
        'data' => [
            'processed' => $result['processed'],
            'success_count' => $result['success_count'],
            'failed_count' => $result['failed_count']
        ]
    ];
}, true);

$router->apiPost('/settings/backup/run', function ($params, $data) {
    $controller = new Controllers\SettingController();
    return $controller->apiRunBackup($params, $data);
}, true);

$router->apiGet('/settings/backup/history', function ($params) {
    $controller = new Controllers\SettingController();
    return $controller->apiBackupHistory($params);
}, true);

// デモデータ生成API
$router->apiPost('/settings/demo-data', function ($params, $data) {
    $controller = new Controllers\SettingController();
    return $controller->apiManageDemoData($params, $data);
}, true);

$router->apiPost('/settings/scim-token', function ($params, $data) {
    $controller = new Controllers\SettingController();
    return $controller->apiGenerateScimToken($params, $data);
}, true);

$router->apiPost('/settings/scim-token/:id', function ($params, $data) {
    $controller = new Controllers\SettingController();
    return $controller->apiToggleScimToken($params, $data);
}, true);

// 通知関連のルート
// 通知一覧
$router->get('/notifications', function () {
    $controller = new Controllers\NotificationController();
    $controller->index();
}, true);

// 通知設定
$router->get('/notifications/settings', function () {
    $controller = new Controllers\NotificationController();
    $controller->settings();
}, true);

// 未読通知取得API
$router->apiGet('/notifications/unread', function () {
    $controller = new Controllers\NotificationController();
    return $controller->apiGetUnread();
}, true);

// 通知既読API
$router->apiPost('/notifications/:id/read', function ($params) {
    $controller = new Controllers\NotificationController();
    return $controller->apiMarkAsRead($params);
}, true);

// 全通知既読API
$router->apiPost('/notifications/read-all', function () {
    $controller = new Controllers\NotificationController();
    return $controller->apiMarkAllAsRead();
}, true);

// 通知設定更新API
$router->apiPost('/notifications/settings', function ($params, $data) {
    $controller = new Controllers\NotificationController();
    return $controller->apiUpdateSettings($params, $data);
}, true);

// 未読通知取得API
$router->apiGet('/notifications/unread', function () {
    $controller = new Controllers\NotificationController();
    return $controller->apiGetUnread();
}, true);

// ホーム画面用API
$router->apiGet('/home/unread-counts', function () {
    $controller = new Controllers\HomeController();
    return $controller->apiGetUnreadCounts();
}, true);

// PWA / Push API
$router->apiGet('/pwa/config', function () {
    $controller = new Controllers\PwaController();
    return $controller->apiConfig();
}, true);

$router->apiPost('/pwa/subscribe', function ($params, $data) {
    $controller = new Controllers\PwaController();
    return $controller->apiSubscribe($params, $data);
}, true);

$router->apiPost('/pwa/unsubscribe', function ($params, $data) {
    $controller = new Controllers\PwaController();
    return $controller->apiUnsubscribe($params, $data);
}, true);

$router->apiPost('/pwa/test-push', function () {
    $controller = new Controllers\PwaController();
    return $controller->apiTestPush();
}, true);

// WEBデータベース関連のルート
$router->get('/webdatabase', function () {
    $controller = new Controllers\WebDatabaseController();
    $controller->index();
}, true);

$router->get('/webdatabase/create', function () {
    $controller = new Controllers\WebDatabaseController();
    $controller->create();
}, true);

$router->get('/webdatabase/edit/:id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    $controller->edit($params);
}, true);

$router->get('/webdatabase/fields/:id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    $controller->fields($params);
}, true);

$router->get('/webdatabase/records/:id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    $controller->records($params);
}, true);

$router->get('/webdatabase/create-record/:id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    $controller->createRecord($params);
}, true);

$router->get('/webdatabase/edit/:id/:record_id', function ($params) {
    $params['record_id'] = $params['record_id'] ?? null;
    $controller = new Controllers\WebDatabaseController();
    $controller->editRecord($params);
}, true);

$router->get('/webdatabase/view/:id/:record_id', function ($params) {
    $params['record_id'] = $params['record_id'] ?? null;
    $controller = new Controllers\WebDatabaseController();
    $controller->viewRecord($params);
}, true);

// WEBデータベースAPI
$router->apiGet('/webdatabase', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiGetDatabases($params);
}, true);

$router->apiPost('/webdatabase', function ($params, $data) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiCreateDatabase($params, $data);
}, true);

$router->apiPost('/webdatabase/setup-demo-samples', function ($params, $data) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiSetupDemoSamples($params, $data);
}, true);

$router->apiGet('/webdatabase/:id/records', function ($params) {
    // error_log('Routerr: apiGetRecords' . json_encode(['params: ' . $params]));
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiGetRecords($params);
}, true);

$router->apiPost('/webdatabase/:id', function ($params, $data) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiUpdateDatabase($params, $data);
}, true);

$router->apiDelete('/webdatabase/:id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiDeleteDatabase($params);
}, true);

$router->apiPost('/webdatabase/:id/fields', function ($params, $data) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiCreateField($params, $data);
}, true);

$router->apiPost('/webdatabase/fields/:id', function ($params, $data) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiUpdateField($params, $data);
}, true);

$router->apiDelete('/webdatabase/fields/:id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiDeleteField($params);
}, true);

$router->apiPost('/webdatabase/record/:id', function ($params, $data) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiCreateRecord($params, $data);
}, true);

$router->apiPost('/webdatabase/record/:id/:record_id', function ($params, $data) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiUpdateRecord($params, $data);
}, true);

$router->apiDelete('/webdatabase/record/:id/:record_id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiDeleteRecord($params);
}, true);

// CSVエクスポート関連のルート
$router->get('/webdatabase/export-csv/:id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    $controller->exportCsv($params);
}, true);

$router->apiGet('/webdatabase/:id/export-csv', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiExportCsv($params);
}, true);

// CSVインポート関連のルート
$router->get('/webdatabase/import-csv/:id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    $controller->importCsv($params);
}, true);

$router->apiPost('/webdatabase/:id/import-csv', function ($params, $data) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiImportCsv($params, $data);
}, true);

// フィールド情報取得API
$router->apiGet('/webdatabase/fields/:id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiGetField($params);
}, true);

$router->apiPost('/webdatabase/fields/set-title', function ($params, $data) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiSetTitleField($params, $data);
}, true);

$router->apiGet('/webdatabase/:id/fields', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiGetDatabaseFields($params);
}, true);

$router->apiGet('/webdatabase/:id/form-layout', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiGetFormLayout($params);
}, true);

$router->apiPost('/webdatabase/:id/fields/layout', function ($params, $data) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiSaveFieldLayout($params, $data);
}, true);

$router->apiGet('/webdatabase/:id/analytics', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiGetAnalytics($params);
}, true);

// リレーション関連API
$router->apiGet('/webdatabase/relation-targets/:id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiGetRelationTargets($params);
}, true);

$router->apiGet('/webdatabase/related-records/:record_id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiGetRelatedRecords($params);
}, true);

$router->apiPost('/webdatabase/relations/:record_id', function ($params, $data) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiSaveRelations($params, $data);
}, true);

$router->apiGet('/webdatabase/lookup/:record_id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiGetLookupValue($params);
}, true);

$router->apiGet('/webdatabase/reverse-relations/:record_id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiGetReverseRelations($params);
}, true);

$router->apiGet('/webdatabase/all-databases', function () {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiGetAllDatabases();
}, true);

$router->apiGet('/webdatabase/:id/views', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiGetViews($params);
}, true);

$router->apiPost('/webdatabase/:id/views', function ($params, $data) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiSaveView($params, $data);
}, true);

$router->apiDelete('/webdatabase/views/:view_id', function ($params) {
    $controller = new Controllers\WebDatabaseController();
    return $controller->apiDeleteView($params);
}, true);

// タスク管理ルーティング
// 複数形リダイレクト
$router->get('/tasks', function () { header('Location: ' . BASE_PATH . '/task'); exit; }, true);
$router->get('/facilities', function () { header('Location: ' . BASE_PATH . '/facility'); exit; }, true);

// タスク管理ダッシュボード
$router->get('/task', function () {
    $controller = new Controllers\TaskController();
    $controller->index();
}, true);

// 個人タスクボード一覧
$router->get('/task/my-boards', function () {
    $controller = new Controllers\TaskController();
    $controller->myBoards();
}, true);

// チームタスクボード一覧
$router->get('/task/team-boards', function () {
    $controller = new Controllers\TaskController();
    $controller->teamBoards();
}, true);

// 組織タスクボード一覧
$router->get('/task/organization-boards', function () {
    $controller = new Controllers\TaskController();
    $controller->organizationBoards();
}, true);

// チーム一覧
$router->get('/task/teams', function () {
    $controller = new Controllers\TaskController();
    $controller->teams();
}, true);

// チーム作成画面
$router->get('/task/create-team', function () {
    $controller = new Controllers\TaskController();
    $controller->createTeam();
}, true);

// チーム編集画面
$router->get('/task/edit-team/:id', function ($params) {
    $controller = new Controllers\TaskController();
    $controller->editTeam($params);
}, true);

// チーム詳細画面
$router->get('/task/team/:id', function ($params) {
    $controller = new Controllers\TaskController();
    $controller->viewTeam($params);
}, true);

// タスクボード作成画面
$router->get('/task/create-board', function () {
    $controller = new Controllers\TaskController();
    $controller->createBoard();
}, true);

// タスクボード編集画面
$router->get('/task/edit-board/:id', function ($params) {
    $controller = new Controllers\TaskController();
    $controller->editBoard($params);
}, true);

// タスクボード表示画面
$router->get('/task/board/:id', function ($params) {
    $controller = new Controllers\TaskController();
    $controller->board($params);
}, true);

// カード詳細画面
$router->get('/task/card/:id', function ($params) {
    $controller = new Controllers\TaskController();
    $controller->card($params);
}, true);

// カード作成画面
$router->get('/task/create-card/:list_id', function ($params) {
    $controller = new Controllers\TaskController();
    $controller->createCard($params);
}, true);

// カード編集画面
$router->get('/task/edit-card/:id', function ($params) {
    $controller = new Controllers\TaskController();
    $controller->editCard($params);
}, true);

// マイタスク一覧
$router->get('/task/my-tasks', function () {
    $controller = new Controllers\TaskController();
    $controller->myTasks();
}, true);

// API: タスク管理関連のAPI

// API: チーム作成
$router->apiPost('/task/teams', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiCreateTeam($params, $data);
}, true);

// API: チーム更新
$router->apiPost('/task/teams/:id', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiUpdateTeam($params, $data);
}, true);

// API: チーム削除
$router->apiDelete('/task/teams/:id', function ($params) {
    $controller = new Controllers\TaskController();
    return $controller->apiDeleteTeam($params);
}, true);

// API: タスクボード作成
$router->apiPost('/task/boards', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiCreateBoard($params, $data);
}, true);

// API: タスクボード更新
$router->apiPost('/task/boards/:id', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiUpdateBoard($params, $data);
}, true);

// API: タスクボード削除
$router->apiDelete('/task/boards/:id', function ($params) {
    $controller = new Controllers\TaskController();
    return $controller->apiDeleteBoard($params);
}, true);

// API: タスクボード概要情報取得
$router->apiGet('/task/boards/:id/summary', function ($params) {
    $controller = new Controllers\TaskController();
    return $controller->apiGetBoardSummary($params);
}, true);

// API: タスクリスト作成
$router->apiPost('/task/lists', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiCreateList($params, $data);
}, true);

// API: タスクリスト更新
$router->apiPost('/task/lists/:id', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiUpdateList($params, $data);
}, true);

// API: タスクリスト削除
$router->apiDelete('/task/lists/:id', function ($params) {
    $controller = new Controllers\TaskController();
    return $controller->apiDeleteList($params);
}, true);

// API: タスクリスト情報取得
$router->apiGet('/task/lists/:id', function ($params) {
    $controller = new Controllers\TaskController();
    return $controller->apiGetList($params);
}, true);

// API: リスト順序更新
$router->apiPost('/task/lists/:id/order', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiUpdateListOrder($params, $data);
}, true);

// API: タスクカード作成
$router->apiPost('/task/cards', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiCreateCard($params, $data);
}, true);

// API: タスクカード更新
$router->apiPost('/task/cards/:id', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiUpdateCard($params, $data);
}, true);

// API: タスクカード削除
$router->apiDelete('/task/cards/:id', function ($params) {
    $controller = new Controllers\TaskController();
    return $controller->apiDeleteCard($params);
}, true);

// API: タスクカード情報取得
$router->apiGet('/task/cards/:id', function ($params) {
    $controller = new Controllers\TaskController();
    return $controller->apiGetCard($params);
}, true);

// API: カード順序更新
$router->apiPost('/task/cards/:id/order', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiUpdateCardOrder($params, $data);
}, true);

// API: コメント追加
$router->apiPost('/task/cards/:id/comments', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiAddComment($params, $data);
}, true);

// API: ラベル作成
$router->apiPost('/task/labels', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiCreateLabel($params, $data);
}, true);

// API: ボードメンバー追加
$router->apiPost('/task/board-members', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiAddBoardMember($params, $data);
}, true);

// API: チェックリスト作成
$router->apiPost('/task/cards/:id/checklists', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiCreateChecklist($params, $data);
}, true);

// API: チェックリスト項目更新
$router->apiPost('/task/checklist-items/:id', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiUpdateChecklistItem($params, $data);
}, true);

// API: チェックリスト削除
$router->apiDelete('/task/checklists/:id', function ($params) {
    $controller = new Controllers\TaskController();
    return $controller->apiDeleteChecklist($params);
}, true);

// API: チェックリスト項目追加
$router->apiPost('/task/checklists/:id/items', function ($params, $data) {
    $controller = new Controllers\TaskController();
    return $controller->apiAddChecklistItem($params, $data);
}, true);

// API: チェックリスト項目削除
$router->apiDelete('/task/checklist-items/:id', function ($params) {
    $controller = new Controllers\TaskController();
    return $controller->apiDeleteChecklistItem($params);
}, true);

// 日報管理
$router->get('/daily-report', function () {
    $controller = new Controllers\DailyReportController();
    $controller->index();
}, true);

$router->get('/daily-report/list', function () {
    $controller = new Controllers\DailyReportController();
    $controller->list();
}, true);

$router->get('/daily-report/week', function () {
    $controller = new Controllers\DailyReportController();
    $controller->week();
}, true);

$router->get('/daily-report/month', function () {
    $controller = new Controllers\DailyReportController();
    $controller->month();
}, true);

$router->get('/daily-report/timeline', function () {
    $controller = new Controllers\DailyReportController();
    $controller->timeline();
}, true);

$router->get('/daily-report/create', function () {
    $controller = new Controllers\DailyReportController();
    $controller->create();
}, true);

$router->get('/daily-report/edit/:id', function ($params) {
    $controller = new Controllers\DailyReportController();
    $controller->edit($params);
}, true);

$router->get('/daily-report/view/:id', function ($params) {
    $controller = new Controllers\DailyReportController();
    $controller->viewDetail($params);
}, true);

$router->get('/daily-report/templates', function () {
    $controller = new Controllers\DailyReportController();
    $controller->templates();
}, true);

$router->get('/daily-report/template/edit/:id', function ($params) {
    $controller = new Controllers\DailyReportController();
    $controller->editTemplate($params);
}, true);

$router->get('/daily-report/stats', function () {
    $controller = new Controllers\DailyReportController();
    $controller->stats();
}, true);

$router->get('/daily-report/analysis', function () {
    $controller = new Controllers\DailyReportController();
    $controller->analysis();
}, true);

// 日報機能用API
$router->apiPost('/daily-report', function ($params, $data) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiCreate($params, $data);
}, true);

$router->apiPost('/daily-report/template/:id', function ($params, $data) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiSaveTemplate($params, $data);
}, true);

$router->apiPost('/daily-report/template', function ($params, $data) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiSaveTemplate($params, $data);
}, true);

$router->apiPost('/daily-report/targets', function ($params, $data) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiSaveMonthlyTarget($params, $data);
}, true);

$router->apiPost('/daily-report/:id', function ($params, $data) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiUpdate($params, $data);
}, true);

$router->apiDelete('/daily-report/:id', function ($params) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiDelete($params);
}, true);

$router->apiPost('/daily-report/:id/comment', function ($params, $data) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiAddComment($params, $data);
}, true);

$router->apiPost('/daily-report/:id/like', function ($params) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiToggleLike($params);
}, true);

$router->apiGet('/daily-report/count', function ($params) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiGetReadableReportsCount($params);
}, true);



$router->get('/daily-report/template/edit/:id', function ($params) {
    $controller = new Controllers\DailyReportController();
    $controller->editTemplate($params);
}, true);

$router->get('/daily-report/template/edit', function () {
    $controller = new Controllers\DailyReportController();
    $controller->editTemplate(['id' => null]);
}, true);


$router->apiDelete('/daily-report/template/:id', function ($params) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiDeleteTemplate($params);
}, true);

$router->apiGet('/daily-report/stats', function ($params) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiGetStats($params);
}, true);

$router->apiGet('/daily-report/analysis-masters', function ($params) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiGetAnalysisMasters($params);
}, true);

$router->apiPost('/daily-report/master/:type', function ($params, $data) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiSaveMaster($params, $data);
}, true);

$router->apiDelete('/daily-report/master/:type/:id', function ($params) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiDeleteMaster($params);
}, true);

$router->apiDelete('/daily-report/targets/:id', function ($params) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiDeleteMonthlyTarget($params);
}, true);

$router->apiGet('/daily-report/export-csv', function ($params) {
    $controller = new Controllers\DailyReportController();
    return $controller->apiExportCsv($params);
}, true);

// 全文検索
$router->get('/search', function () {
    $controller = new Controllers\SearchController();
    $controller->index();
}, true);

$router->apiGet('/search', function ($params) {
    $controller = new Controllers\SearchController();
    return $controller->apiSearch($params);
}, true);

// 外部連携
$router->get('/integrations', function () {
    $controller = new Controllers\IntegrationController();
    $controller->index();
}, true);

$router->get('/integrations/calendar.ics', function () {
    $controller = new Controllers\IntegrationController();
    $controller->calendarIcs();
}, true);

$router->get('/integrations/calendar/subscription/:token', function ($params) {
    $controller = new Controllers\IntegrationController(false);
    $controller->publicCalendarIcs($params);
});

$router->get('/integrations/export-csv', function () {
    $controller = new Controllers\IntegrationController();
    $controller->exportCsv();
}, true);

$router->post('/integrations/calendar-subscriptions', function () {
    $controller = new Controllers\IntegrationController();
    $controller->storeSubscription();
}, true);

$router->post('/integrations/calendar-subscriptions/:id/update', function ($params) {
    $controller = new Controllers\IntegrationController();
    $controller->updateSubscription($params);
}, true);

$router->post('/integrations/calendar-subscriptions/:id/delete', function ($params) {
    $controller = new Controllers\IntegrationController();
    $controller->deleteSubscription($params);
}, true);

$router->post('/integrations/calendar-subscriptions/:id/sync', function ($params) {
    $controller = new Controllers\IntegrationController();
    $controller->syncSubscription($params);
}, true);

$router->apiPost('/integrations/settings', function ($params, $data) {
    $controller = new Controllers\IntegrationController();
    return $controller->apiSaveSettings($params, $data);
}, true);

$router->apiPost('/integrations/regenerate-token', function ($params, $data) {
    $controller = new Controllers\IntegrationController();
    return $controller->apiRegenerateToken();
}, true);

$router->apiPost('/integrations/import-ics', function ($params, $data) {
    $controller = new Controllers\IntegrationController();
    return $controller->apiImportIcs($params, $data);
}, true);

$router->apiGet('/integrations/data', function ($params) {
    $controller = new Controllers\IntegrationController();
    return $controller->apiData($params);
}, true);

// アドレス帳
$router->get('/address-book', function () {
    $controller = new Controllers\AddressBookController();
    $controller->index();
}, true);

$router->get('/address-book/create', function () {
    $controller = new Controllers\AddressBookController();
    $controller->create();
}, true);

$router->post('/address-book/store', function () {
    $controller = new Controllers\AddressBookController();
    $controller->store();
}, true);

$router->get('/address-book/view/{id}', function ($params) {
    $controller = new Controllers\AddressBookController();
    $controller->show($params);
}, true);

$router->get('/address-book/edit/{id}', function ($params) {
    $controller = new Controllers\AddressBookController();
    $controller->edit($params);
}, true);

$router->post('/address-book/update/{id}', function ($params) {
    $controller = new Controllers\AddressBookController();
    $controller->update($params);
}, true);

$router->get('/address-book/delete/{id}', function ($params) {
    $controller = new Controllers\AddressBookController();
    $controller->delete($params);
}, true);

// 名刺管理
$router->get('/address-book/create-from-card', function () {
    $controller = new Controllers\AddressBookController();
    $controller->createFromCard();
}, true);

$router->post('/address-book/store-from-card', function () {
    $controller = new Controllers\AddressBookController();
    $controller->storeFromCard();
}, true);

$router->post('/address-book/upload-card/{id}', function ($params) {
    $controller = new Controllers\AddressBookController();
    $controller->uploadBusinessCard($params);
}, true);

$router->post('/address-book/upload-card-batch/{id}', function ($params) {
    $controller = new Controllers\AddressBookController();
    $controller->uploadBusinessCardBatch($params);
}, true);

$router->post('/address-book/ocr-card/{id}', function ($params) {
    $controller = new Controllers\AddressBookController();
    $controller->ocrBusinessCard($params);
}, true);

$router->get('/address-book/card-image/{id}', function ($params) {
    $controller = new Controllers\AddressBookController();
    $controller->previewBusinessCard($params);
}, true);

$router->post('/address-book/delete-card/{id}', function ($params) {
    $controller = new Controllers\AddressBookController();
    $controller->deleteBusinessCard($params);
}, true);

$router->get('/address-book/export-vcard/{id}', function ($params) {
    $controller = new Controllers\AddressBookController();
    $controller->exportVcard($params);
}, true);

$router->post('/address-book/upload-and-ocr', function () {
    $controller = new Controllers\AddressBookController();
    $controller->uploadAndOcr();
}, true);

$router->get('/address-book/temp-card-image/{filename}', function ($params) {
    $controller = new Controllers\AddressBookController();
    $controller->tempCardImage($params);
}, true);

// 施設予約
$router->get('/facility', function () {
    $controller = new Controllers\FacilityController();
    $controller->index();
}, true);

$router->get('/facility/create', function () {
    $controller = new Controllers\FacilityController();
    $controller->create();
}, true);

$router->post('/facility/store', function () {
    $controller = new Controllers\FacilityController();
    $controller->store();
}, true);

$router->get('/facility/delete/{id}', function ($params) {
    $controller = new Controllers\FacilityController();
    $controller->delete($params);
}, true);

$router->get('/facility/manage', function () {
    $controller = new Controllers\FacilityController();
    $controller->manage();
}, true);

$router->post('/facility/add-facility', function () {
    $controller = new Controllers\FacilityController();
    $controller->addFacility();
}, true);

$router->get('/facility/delete-facility/{id}', function ($params) {
    $controller = new Controllers\FacilityController();
    $controller->deleteFacility($params);
}, true);

// SCIM 2.0 API（Bearer Token認証）
$router->apiGet('/scim/v2/ServiceProviderConfig', function () {
    $controller = new Controllers\ScimController();
    return $controller->apiServiceProviderConfig();
});

$router->apiGet('/scim/v2/Users', function () {
    $controller = new Controllers\ScimController();
    return $controller->apiListUsers();
});

$router->apiPost('/scim/v2/Users', function ($params, $data) {
    $controller = new Controllers\ScimController();
    return $controller->apiCreateUser($params, $data);
});

$router->apiGet('/scim/v2/Users/:id', function ($params) {
    $controller = new Controllers\ScimController();
    return $controller->apiGetUser($params);
});

$router->api('PUT', '/scim/v2/Users/:id', function ($params, $data) {
    $controller = new Controllers\ScimController();
    return $controller->apiPutUser($params, $data);
});

$router->api('PATCH', '/scim/v2/Users/:id', function ($params, $data) {
    $controller = new Controllers\ScimController();
    return $controller->apiPatchUser($params, $data);
});

$router->apiDelete('/scim/v2/Users/:id', function ($params) {
    $controller = new Controllers\ScimController();
    return $controller->apiDeleteUser($params);
});

// ヘルプ・利用規約
$router->get('/help', function () {
    $controller = new Controllers\HelpController();
    $controller->index();
}, true);

$router->get('/terms', function () {
    $controller = new Controllers\HelpController();
    $controller->terms();
}, true);

$router->get('/help/install-manual', function () {
    $controller = new Controllers\HelpController();
    $controller->installManual();
}, true);

$router->get('/help/admin-manual', function () {
    $controller = new Controllers\HelpController();
    $controller->adminManual();
}, true);

// CSVインポート
$router->get('/admin/csv-import', function () {
    $controller = new Controllers\CsvImportController();
    $controller->index();
}, true);

$router->post('/admin/csv-import/users', function () {
    $controller = new Controllers\CsvImportController();
    $controller->importUsers();
}, true);

$router->post('/admin/csv-import/organizations', function () {
    $controller = new Controllers\CsvImportController();
    $controller->importOrganizations();
}, true);

$router->post('/admin/csv-import/address-book', function () {
    $controller = new Controllers\CsvImportController();
    $controller->importAddressBook();
}, true);

$router->get('/admin/csv-import/sample/:type', function ($params) {
    $controller = new Controllers\CsvImportController();
    $controller->downloadSample($params['type']);
}, true);

// ファイル共有（旧 /drive 互換）
$router->get('/file-share', function () {
    $controller = new Controllers\DriveController();
    $controller->index();
});

$router->get('/file-share/upload', function () {
    $controller = new Controllers\DriveController();
    $controller->upload();
});

$router->post('/file-share/upload', function () {
    $controller = new Controllers\DriveController();
    $controller->store();
});

$router->get('/file-share/file/:id', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->show($params);
});

$router->get('/file-share/download/:id', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->download($params);
});

$router->post('/file-share/file/:id/delete', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->delete($params);
});

$router->post('/file-share/file/:id/share-links', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->createShareLink($params);
});

$router->post('/file-share/share/:id/revoke', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->revokeShareLink($params);
});

$router->get('/file-share/share/:token', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->shareAccess($params);
});

$router->post('/file-share/share/:token', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->shareAccess($params);
});

// 旧ルート互換
$router->get('/drive', function () {
    $controller = new Controllers\DriveController();
    $controller->index();
});

$router->get('/drive/upload', function () {
    $controller = new Controllers\DriveController();
    $controller->upload();
});

$router->post('/drive/upload', function () {
    $controller = new Controllers\DriveController();
    $controller->store();
});

$router->get('/drive/file/:id', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->show($params);
});

$router->get('/drive/download/:id', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->download($params);
});

$router->post('/drive/file/:id/delete', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->delete($params);
});

$router->post('/drive/file/:id/share-links', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->createShareLink($params);
});

$router->post('/drive/share/:id/revoke', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->revokeShareLink($params);
});

$router->get('/drive/share/:token', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->shareAccess($params);
});

$router->post('/drive/share/:token', function ($params) {
    $controller = new Controllers\DriveController();
    $controller->shareAccess($params);
});

// ファイル管理
$router->get('/files', function () {
    $controller = new Controllers\FileManagerController();
    $controller->index();
});

$router->get('/files/folder/create', function () {
    $controller = new Controllers\FileManagerController();
    $controller->createFolder();
});

$router->post('/files/folder', function () {
    $controller = new Controllers\FileManagerController();
    $controller->storeFolder();
});

$router->get('/files/folder/:id', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->folder($params);
});

$router->get('/files/folder/:id/edit', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->editFolder($params);
});

$router->post('/files/folder/:id/update', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->updateFolder($params);
});

$router->post('/files/folder/:id/delete', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->deleteFolder($params);
});

$router->get('/files/upload', function () {
    $controller = new Controllers\FileManagerController();
    $controller->upload();
});

$router->post('/files/upload', function () {
    $controller = new Controllers\FileManagerController();
    $controller->storeFile();
});

$router->get('/files/file/:id', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->showFile($params);
});

$router->get('/files/download/:id', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->download($params);
});

$router->post('/files/file/:id/update', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->updateFile($params);
});

$router->post('/files/file/:id/permissions', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->updatePermissions($params);
});

$router->post('/files/file/:id/checkout', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->checkoutFile($params);
});

$router->get('/files/file/:id/checkout', function ($params) {
    $_SESSION['flash_error'] = tr_text('チェックアウトは詳細画面のボタンから実行してください。', 'Please use the checkout button on the file detail page.');
    header('Location: ' . BASE_PATH . '/files/file/' . (int)($params['id'] ?? 0));
    exit;
});

$router->post('/files/file/:id/checkin', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->releaseCheckout($params);
});

$router->get('/files/file/:id/checkin', function ($params) {
    $_SESSION['flash_error'] = tr_text('チェックアウト解除は詳細画面のボタンから実行してください。', 'Please use the check-in button on the file detail page.');
    header('Location: ' . BASE_PATH . '/files/file/' . (int)($params['id'] ?? 0));
    exit;
});

$router->post('/files/file/:id/request-approval', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->requestApproval($params);
});

$router->get('/files/file/:id/request-approval', function ($params) {
    $_SESSION['flash_error'] = tr_text('承認申請は詳細画面のボタンから実行してください。', 'Please use the approval request button on the file detail page.');
    header('Location: ' . BASE_PATH . '/files/file/' . (int)($params['id'] ?? 0));
    exit;
});

$router->post('/files/approval/:request_id/approve', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->approveRequest($params);
});

$router->post('/files/approval/:request_id/reject', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->rejectRequest($params);
});

$router->post('/files/file/:id/delete', function ($params) {
    $controller = new Controllers\FileManagerController();
    $controller->deleteFile($params);
});

// 掲示板
$router->get('/bulletin', function () {
    $controller = new Controllers\BulletinController();
    $controller->index();
});

$router->get('/bulletin/create', function () {
    $controller = new Controllers\BulletinController();
    $controller->create();
});

$router->post('/bulletin', function () {
    $controller = new Controllers\BulletinController();
    $controller->store();
});

$router->get('/bulletin/categories', function () {
    $controller = new Controllers\BulletinController();
    $controller->categories();
});

$router->post('/bulletin/categories', function () {
    $controller = new Controllers\BulletinController();
    $controller->addCategory();
});

$router->post('/bulletin/categories/:id/update', function ($params) {
    $controller = new Controllers\BulletinController();
    $controller->updateCategory($params);
});

$router->post('/bulletin/categories/:id/delete', function ($params) {
    $controller = new Controllers\BulletinController();
    $controller->deleteCategory($params);
});

$router->get('/bulletin/:id', function ($params) {
    $controller = new Controllers\BulletinController();
    $controller->show($params);
});

$router->get('/bulletin/:id/edit', function ($params) {
    $controller = new Controllers\BulletinController();
    $controller->edit($params);
});

$router->post('/bulletin/:id/update', function ($params) {
    $controller = new Controllers\BulletinController();
    $controller->update($params);
});

$router->post('/bulletin/:id/delete', function ($params) {
    $controller = new Controllers\BulletinController();
    $controller->delete($params);
});

$router->post('/bulletin/:id/comment', function ($params) {
    $controller = new Controllers\BulletinController();
    $controller->addComment($params);
});

$router->post('/bulletin/comment/:id/delete', function ($params) {
    $controller = new Controllers\BulletinController();
    $controller->deleteComment($params);
});

// リクエストのディスパッチ（ルーティング処理の実行）
$router->dispatch();
